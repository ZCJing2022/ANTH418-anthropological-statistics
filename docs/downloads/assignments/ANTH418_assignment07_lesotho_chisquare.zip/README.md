# Assignment 7: Lithic Raw Materials in Highland Lesotho

**Week:** 11  
**Statistical focus:** Chi-Square and Tests of Proportions

## Research question

Does lithic raw-material composition differ among the four published Sehonghong archaeological layers — BAS, RBL-CLBRF, RF, and BARF — and which layer/material combinations contribute most strongly to the association?

## Published case study

Gregory, Alex, Peter Mitchell, and Justin Pargeter. 2023. Raw Material Surveys and Their Behavioral Implications in Highland Lesotho. *Journal of Paleolithic Archaeology* 6:18.

DOI: https://doi.org/10.1007/s41982-023-00138-y

## Teaching comparison

The teaching file contains **1,060 source observations** across:

- BAS
- RBL-CLBRF
- RF
- BARF

The seven source raw-material categories are preserved in the CSV.

For the chi-square teaching analysis, students create:

- CrystallineQuartz
- Dolerite
- FineChert
- Other = Agate + CoarseChert + Quartzite + Sandstone

`Other` is an analysis-time teaching grouping, not a source category.

## Workflow

1. Read the case-study article before analysis.
2. Read `codebook.md` and `provenance.md`.
3. Open `assignment07_lesotho_chisquare.qmd`.
4. Render once before editing to confirm that R, packages, and data paths work.
5. Work through **Group categories → Build contingency table → Visualize → Check expected counts → Chi-square → Residuals → Effect size → Interpret**.
6. Keep only output needed to support your reasoning.

## Recurring interpretation questions

1. What is the unit of analysis?
2. What does the chi-square test tell you about association between archaeological layer and raw-material composition?
3. Which cells contribute most strongly, and what does Cramer's V add beyond the p-value?
4. What behavioral, procurement, or mobility claim does the association not establish by itself?

## Data

The student file `data/lesotho_raw_material.csv` is a frozen teaching dataset built reproducibly from the published source data. See `provenance.md`.
