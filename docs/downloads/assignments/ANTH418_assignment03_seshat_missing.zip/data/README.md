# Student teaching data

The teaching dataset `seshat_missingness_counts.csv` is created by:

```r
source("scripts/03_build_teaching_data.R")
```

Do not edit the generated CSV manually.
