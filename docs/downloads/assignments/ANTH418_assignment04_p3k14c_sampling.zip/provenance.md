# Data Provenance

## Parent publication

Bird, Darcy, Lux Miranda, Marc Vander Linden, Erick Robinson, R. Kyle Bocinsky, Chris Nicholson, et al. 2022. p3k14c, a Synthetic Global Database of Archaeological Radiocarbon Dates. *Scientific Data* 9:27.

**DOI:** https://doi.org/10.1038/s41597-022-01118-7

## Frozen case-study source

Repository: `people3k/PopulationExpansion2025`

Pinned Git commit:

`f8aa38b84e435ec0d87dab7a726e3881b87edad5`

Repository file:

`data/SoCaldates.csv`

Verified Git blob:

`09d1ae6d0e938fd9b7040c3cdececd7808244a56`

Local source file:

`source/p3k14c_socal.csv`

## How the 984-row subset was produced

The repository's `CaseStudyRadiocarbon.R` reads the broader `RawP3Kc14.csv` dataset and defines the Southern California case-study subset with:

```r
Latitude > 27 &
Latitude < 36.01 &
Longitude > -122 &
Longitude < -116 &
Material != "SHELL"
```

The resulting file contains 984 radiocarbon determinations. It is **not the full p3k14c database**.

## Teaching file

`data/p3k14c_sampling.csv`

Verified characteristics:

- no missing `age`;
- no missing `error`;
- no missing latitude/longitude coordinates;
- no shell observations;
- all rows have source `UWyo2021`;
- 3 missing `site_id`;
- 559 missing `site_name`;
- no duplicate laboratory identifiers.

Missing site metadata are retained because they are source metadata gaps rather than evidence that a radiocarbon determination is invalid.

## Unit of analysis

One radiocarbon determination.

## Important interpretation note

`age` is conventional uncalibrated radiocarbon age in years BP. Assignment 4 uses the mean of this numeric variable to demonstrate sampling distributions and sampling bias. It should not be interpreted as a calibrated calendar date, occupation date, or direct regional population chronology.

## Build script

The teaching dataset was built reproducibly in the instructor repository using:

`scripts/build_teaching_data.R`

The build script is not included in the student package and is not needed to complete this assignment.
