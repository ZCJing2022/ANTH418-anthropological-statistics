# Codebook

Teaching file: `p3k14c_sampling.csv`

**Teaching population:** 984 radiocarbon determinations in the frozen Southern California case-study subset.

**Unit of analysis:** one radiocarbon determination.

| Variable | Type | Meaning | Units |
|---|---|---|---|
| `lab_id` | character | Radiocarbon laboratory identifier | — |
| `age` | numeric | Conventional **uncalibrated** radiocarbon age | years BP |
| `error` | numeric | Reported radiocarbon error | years |
| `material` | character | Dated material | — |
| `method` | character | Dating method | — |
| `longitude` | numeric | Longitude | decimal degrees |
| `latitude` | numeric | Latitude | decimal degrees |
| `site_id` | character | Site identifier; may be missing in the source | — |
| `site_name` | character | Site name; may be missing in the source | — |
| `source` | character | Parent source/database identifier | — |

The source case-study file contains 3 missing `site_id` values and 559 missing `site_name` values. These are retained metadata gaps, not fabricated values or automatic grounds for deleting a radiocarbon determination.

For Assignment 4, `age` is used as a simple numerical variable for studying sampling distributions. A mean conventional radiocarbon age should not be interpreted as a calibrated calendar date or a direct archaeological occupation date.
