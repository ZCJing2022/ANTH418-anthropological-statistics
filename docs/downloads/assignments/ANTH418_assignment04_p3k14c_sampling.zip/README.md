# Assignment 4: p3k14c Archaeological Radiocarbon Database

**Week:** 7  
**Statistical focus:** Probability, Sampling, and Sampling Distributions

## Research question

How does sample size affect estimates from a radiocarbon dataset, and why does a large biased sample remain biased?

## Published case study

Bird, Darcy, Lux Miranda, Marc Vander Linden, Erick Robinson, R. Kyle Bocinsky, Chris Nicholson, et al. 2022. p3k14c, a Synthetic Global Database of Archaeological Radiocarbon Dates. *Scientific Data* 9:27.

DOI: https://doi.org/10.1038/s41597-022-01118-7

## Teaching population

ANTH418 uses a frozen **Southern California case-study subset** derived from p3k14c, not the full global database.

The student file contains **984 radiocarbon determinations** selected in the source repository by a documented geographic bounding box and exclusion of shell dates.

The unit of analysis is one radiocarbon determination.

## Workflow

1. Read the case-study article before analysis.
2. Read `codebook.md` and `provenance.md`.
3. Open `assignment04_p3k14c_sampling.qmd`.
4. Render once before editing to confirm that R, packages, and data paths work.
5. Work through **Describe → Simulate → Compare sampling distributions → Demonstrate bias → Interpret**.
6. Keep only output needed to support your reasoning.

## Recurring interpretation questions

1. What is the unit of analysis?
2. What happens to sampling variability as sample size increases?
3. What does the restricted sample demonstrate about sampling bias?
4. What archaeological claim does the sampling exercise not support?

## Data

The student file `data/p3k14c_sampling.csv` was built reproducibly from the repository-defined Southern California case-study subset derived from p3k14c. See `provenance.md`.

`age` is conventional uncalibrated radiocarbon age in years BP. In this assignment it is used as a numerical variable for learning about sampling behavior, not as a calibrated estimate of archaeological chronology.
