# ANTH418 Week 6 Practice Workbook

## Getting started

1. Unzip this folder.
2. Open `week06-practice.qmd` in RStudio.
3. Keep the `data` folder beside `week06-practice.qmd`.
4. Work through the workbook from top to bottom.
5. For each exercise: **predict → run → inspect → explain**.
6. Edit the code and write your explanations directly in the QMD.
7. Render the document frequently.
8. When finished, restart R and render the entire document again.

## Files

- `week06-practice.qmd` — editable Week 6 Practice Workbook
- `data/seshat_missingness_counts.csv` — ANTH418 Seshat missing-data teaching summary

## Important

The Seshat teaching CSV is an aggregated three-row summary of the documented 801-observation regression frame. It does not contain 801 individual observations.

The documented counts are:

- 299 known present
- 12 known absent
- 490 missing/unknown

The central analytical distinction is:

**missing or unknown (`NA`) is not the same as documented absence (`0`).**

Do not move `seshat_missingness_counts.csv` out of the `data` folder unless you also update the file path in the workbook.

The goal is not simply to transform variables or remove missing values. You should understand how preparation decisions alter the statistical representation of the evidence and test whether substantive conclusions are sensitive to those decisions.
