# ANTH418 Week 3 Practice Workbook

## Getting started

1. Unzip this folder.
2. Open `week03-practice.qmd` in RStudio.
3. Keep the `data` folder beside `week03-practice.qmd`.
4. Work through the workbook from top to bottom.
5. For each exercise: **predict → run → inspect → explain**.
6. Edit the code and write your explanations directly in the QMD.
7. Render the document frequently.
8. When finished, restart R and render the entire document again.

## Files

- `week03-practice.qmd` — editable Week 3 Practice Workbook
- `data/knipper2020_humans.csv` — teaching dataset used in the workbook

## Important

Do not move `knipper2020_humans.csv` out of the `data` folder unless you also update the file path in the workbook.

The goal is not simply to make the code run. You should understand how concepts become variables, how variables are measured, how research design structures evidence, and what conclusions the design can and cannot support.
