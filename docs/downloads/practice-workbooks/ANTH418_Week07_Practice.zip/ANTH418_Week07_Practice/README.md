# ANTH418 Week 7 Practice Workbook

## Getting started

1. Unzip this folder.
2. Open `week07-practice.qmd` in RStudio.
3. Keep the `data` folder beside `week07-practice.qmd`.
4. Work through the workbook from top to bottom.
5. For each exercise: **predict → run → inspect → explain**.
6. Edit the code and write your explanations directly in the QMD.
7. Render frequently.
8. When finished, restart R and render the entire document again.

## Files

- `week07-practice.qmd` — editable Week 7 Practice Workbook
- `data/p3k14c_sampling.csv` — frozen ANTH418 p3k14c teaching dataset

## Important

The supplied p3k14c teaching file is the empirical sampling frame for this workbook. It contains archaeological radiocarbon determinations selected for the ANTH418 Southern California sampling exercise.

Do not interpret it automatically as a random or complete representation of all archaeological activity in Southern California.

Keep these distinctions clear:

- a **data distribution** describes observed values;
- a **sampling distribution** describes repeated values of a statistic;
- **sampling variability** is not the same as **sampling bias**;
- increasing sample size improves precision but does not repair a biased sampling frame.

Do not move `p3k14c_sampling.csv` out of the `data` folder unless you also update the file path in the workbook.

The goal is not simply to draw random samples. You should understand what population or empirical frame is being sampled, how the sampling design affects inference, and why archaeological representativeness requires substantive reasoning.
