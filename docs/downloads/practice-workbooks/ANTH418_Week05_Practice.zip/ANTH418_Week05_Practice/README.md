# ANTH418 Week 5 Practice Workbook

## Getting started

1. Unzip this folder.
2. Open `week05-practice.qmd` in RStudio.
3. Keep the `data` folder beside `week05-practice.qmd`.
4. Work through the workbook from top to bottom.
5. For each exercise: **predict → run → inspect → explain**.
6. Edit the code and write your explanations directly in the QMD.
7. Render the document frequently.
8. When finished, restart R and render the entire document again.

## Files

- `week05-practice.qmd` — editable Week 5 Practice Workbook
- `data/kinbank_teaching.csv` — frozen ANTH418 Kinbank teaching dataset

## Important

One row in the teaching dataset represents one language represented by at least one Kinbank form record in the frozen ANTH418 snapshot.

`kin_term_count` is the number of Kinbank form records linked to a language. It is not automatically the number of unique kin concepts and should not be interpreted as a direct measure of kinship-system complexity.

Do not move `kinbank_teaching.csv` out of the `data` folder unless you also update the file path in the workbook.

The goal is not simply to make attractive graphs. Use visualization to inspect the structure of the evidence, describe observed patterns, recognize possible dependence, and formulate better questions without confusing description with inference.
