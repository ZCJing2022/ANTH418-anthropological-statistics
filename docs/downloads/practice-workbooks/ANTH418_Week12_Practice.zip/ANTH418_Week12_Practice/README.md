# ANTH418 Week 12 Practice Workbook

## Getting started

1. Extract the full ZIP. Keep the data and documentation folders beside the QMD.
2. Install R and Quarto if needed. The workbook uses base R and requires no additional R packages.
3. Open `week12-practice.qmd` in RStudio, or render from the extracted folder with `quarto render week12-practice.qmd`.
4. Work through the numbered exercises in order. Predict, run, inspect, and explain. Edit your copy of the QMD.
5. Restart R and render the complete document again for the Clean Render Test.

## Files

- `week12-practice.qmd` — editable workbook.
- `data/iron_anova.csv` — unchanged ANTH418 Assignment 8 teaching data for the descriptive audit.
- `documentation/codebook.md` — teaching-variable definitions.
- `documentation/provenance.md` — source, transformation, and limitations.

The worked statistical demonstrations use fictional vessel measurements created inside the QMD. The authentic CSV is used to inspect the analytical units, group counts, variable definitions, and study limitations. Complete the inferential analysis for Assignment 8 in its own QMD.
