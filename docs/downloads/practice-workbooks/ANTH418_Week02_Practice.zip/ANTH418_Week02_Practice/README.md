# ANTH418 Week 2 Practice Workbook

## Getting started

1. Unzip this folder.
2. Open `week02-practice.qmd` in RStudio.
3. Keep the `data` folder beside `week02-practice.qmd`.
4. Work through the workbook from top to bottom.
5. For each exercise: **predict → run → inspect → explain**.
6. Edit the code and write your explanations directly in the QMD.
7. Render the document frequently.
8. When finished, restart R and render the entire document again.

## Files

- `week02-practice.qmd` — editable Week 2 Practice Workbook
- `data/knipper2020_humans.csv` — teaching dataset used in the workbook

## Important

Do not move `knipper2020_humans.csv` out of the `data` folder unless you also update the file path in the workbook.

The goal is not simply to make the code run. You should understand what each step does and be able to explain the result in your own words.
