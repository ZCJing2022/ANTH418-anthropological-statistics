# ANTH418 Week 11 Practice Workbook

## Getting started

1. Unzip this folder.
2. Open `week11-practice.qmd` in RStudio.
3. Keep the `data` folder beside `week11-practice.qmd`.
4. Work through the workbook from top to bottom.
5. For each exercise: **predict → run → inspect → explain**.
6. Edit the code and write your explanations directly in the QMD.
7. Render frequently.
8. When finished, restart R and render the entire document again.

## Files

- `week11-practice.qmd` — editable Week 11 Practice Workbook
- `data/lesotho_raw_material.csv` — frozen ANTH418 Lesotho raw-material teaching dataset

## Week 11 workflow

**define categories → identify units → count → calculate proportions → visualize → construct expected counts → compare observed with expected → inspect residuals → quantify association → return to archaeology**

## Case study

The applied analysis examines the association between archaeological layer and raw-material composition at Sehonghong, Lesotho.

The teaching dataset contains 1,060 observations across four layers:

- BAS
- RBL-CLBRF
- RF
- BARF

The source CSV preserves seven authentic raw-material categories.

For the introductory chi-square analysis, four categories are used:

- CrystallineQuartz
- Dolerite
- FineChert
- Other

`Other` is not a source category. It is created transparently during analysis by combining Agate, CoarseChert, Quartzite, and Sandstone.

## Important

Use **counts**, not percentages, as input to the chi-square test.

Inspect expected counts before interpreting Pearson's chi-square approximation.

The overall chi-square test tells you whether the observed table is inconsistent with independence. Standardized residuals help identify which cells contribute to that pattern. Cramer's V describes overall association strength.

A statistical association between archaeological layer and raw material does not by itself identify a unique behavioral, technological, mobility, exchange, environmental, or taphonomic mechanism.

Do not move `lesotho_raw_material.csv` out of the `data` folder unless you also update the file path in the workbook.
