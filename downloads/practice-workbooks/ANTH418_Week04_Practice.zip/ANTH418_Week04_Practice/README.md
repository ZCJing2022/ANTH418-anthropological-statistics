# ANTH418 Week 4 Practice Workbook

## Getting started

1. Unzip this folder.
2. Open `week04-practice.qmd` in RStudio.
3. Keep the `data` folder beside `week04-practice.qmd`.
4. Work through the workbook from top to bottom.
5. For each exercise: **predict → run → inspect → explain**.
6. Edit the code and write your explanations directly in the QMD.
7. Render the document frequently.
8. When finished, restart R and render the entire document again.

## Files

- `week04-practice.qmd` — editable Week 4 Practice Workbook
- `data/knipper2020_humans.csv` — teaching dataset used in the workbook

## Important

Do not move `knipper2020_humans.csv` out of the `data` folder unless you also update the file path in the workbook.

The goal is not simply to calculate descriptive statistics. You should understand how distribution shape, central tendency, dispersion, resistance, and visualization work together, and you should distinguish statistical description from archaeological explanation.
