# ANTH418 Week 8 Practice Workbook

## Getting started

1. Unzip this folder.
2. Open `week08-practice.qmd` in RStudio.
3. Keep the `data` folder beside `week08-practice.qmd`.
4. Work through the workbook from top to bottom.
5. For each exercise: **predict → run → inspect → explain**.
6. Edit the code and write your explanations directly in the QMD.
7. Render frequently.
8. When finished, restart R and render the entire document again.

## Files

- `week08-practice.qmd` — editable Week 8 Practice Workbook
- `data/teotihuacan_leporids.csv` — frozen ANTH418 Teotihuacan leporid teaching dataset

## Week 8 workflow

**Estimate → quantify uncertainty → specify a null model → construct a null distribution → calculate a p-value → integrate the evidence → return to archaeology**

Keep two resampling procedures distinct:

- **Bootstrap:** resample observations with replacement to study uncertainty in an estimate.
- **Permutation:** shuffle what the null model permits to construct a null distribution.

## Important

The principal applied comparison is defined as:

**Oztoyahualco − Moon Pyramid**

A positive difference therefore means that mean δ13C is higher (less negative) at Oztoyahualco.

The supplied specimens are not automatically a random probability sample of all leporids that lived at Teotihuacan.

A statistical isotope contrast does not by itself establish provisioning, management, breeding, or a unique causal explanation. Archaeological interpretation also requires contextual, chronological, ecological, and other substantive evidence.

Do not move `teotihuacan_leporids.csv` out of the `data` folder unless you also update the file path in the workbook.
