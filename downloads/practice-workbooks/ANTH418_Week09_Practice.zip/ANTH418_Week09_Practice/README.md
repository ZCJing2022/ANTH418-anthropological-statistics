# ANTH418 Week 9 Practice Workbook

## Getting started

1. Unzip this folder.
2. Open `week09-practice.qmd` in RStudio.
3. Keep the `data` folder beside `week09-practice.qmd`.
4. Work through the workbook from top to bottom.
5. For each exercise: **predict → run → inspect → explain**.
6. Edit the code and write your explanations directly in the QMD.
7. Render frequently.
8. When finished, restart R and render the entire document again.

## Files

- `week09-practice.qmd` — editable Week 9 Practice Workbook
- `data/tell_tweini_ttest.csv` — frozen ANTH418 Tell Tweini teaching dataset

## Week 9 case study

The applied comparison uses wild ryegrass (*Lolium cf. multiflorum*) Δ13C from Tell Tweini:

**Middle Bronze Age − Late Bronze Age**

There are 10 observations in each group.

A positive difference means that mean Δ13C is higher in the Middle Bronze Age.

## Statistical workflow

**design → inspect → estimate the difference → standard error → Welch t-test → confidence interval → effect magnitude → diagnostics → alternatives → archaeological interpretation**

Welch's independent-samples t-test is the primary analysis.

The workbook also compares Welch with the equal-variance Student t-test and examines Cohen's d and, as an extension, Hedges' g.

## Important

The outcome is plant **Δ13C**, stored in `isotope_value`. It is not raw measured plant δ13C.

Do not use Shapiro–Wilk or other diagnostic p-values as mechanical pass/fail gates.

A statistical difference in wild ryegrass Δ13C does not by itself establish a unique climatic, agricultural, or environmental mechanism.

Do not move `tell_tweini_ttest.csv` out of the `data` folder unless you also update the file path in the workbook.
