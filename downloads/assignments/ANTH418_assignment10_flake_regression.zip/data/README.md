# Student teaching data

The teaching dataset `flake_regression.csv` is created by:

```r
source("scripts/03_build_teaching_data.R")
```

Do not edit the generated CSV manually.
