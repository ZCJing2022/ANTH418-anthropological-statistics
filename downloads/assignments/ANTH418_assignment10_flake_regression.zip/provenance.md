# Data Provenance

## Publication

Bustos-Pérez, Guillermo, and Javier Baena. 2021. Predicting Flake Mass: A View from Machine Learning. *Lithic Technology* 46(2):130–142.

**DOI:** https://doi.org/10.1080/01977261.2021.1881267

## Original source files

Local source files in the instructor repository:

- `source/bustos_flake_data.csv`
- `source/bustos_flake_analysis.Rmd`

The published source CSV is semicolon-delimited and uses comma decimal marks.

## Teaching file

`data/flake_regression.csv`

The teaching file contains **300 experimental flint flakes** and 7 variables.

## Unit of analysis

One experimental flake.

## Source-to-teaching transformation

The teaching builder:

- reads the source using semicolon delimiters;
- respects comma decimal marks;
- trims source whitespace where necessary;
- standardizes column names;
- retains variables needed for the ANTH418 regression exercise;
- creates a transparent `source_row_id`;
- retains only rows with positive nonmissing `weight` and `mean_thickness`.

No measured values are fabricated or manually altered.

## Source-scale validation

The teaching build explicitly checks the published physical scale:

- weight: 0.5–96.2 g;
- mean thickness: 1.8–20.2 mm;
- length: 15.4–86.8 mm;
- width: 11.9–79.5 mm.

Independent validation confirmed that teaching-file values for length, width, mean thickness, maximum thickness, weight, and platform area match the corresponding source columns.

## Teaching analysis

Assignment 10 uses the simple model:

`log10(weight) ~ mean_thickness`

Validated teaching result:

- n = 300;
- intercept ≈ 0.2100;
- slope ≈ 0.08775 log10(g) per mm;
- 95% CI for slope ≈ 0.07889 to 0.09661;
- R-squared ≈ 0.5605.

Back-transforming the slope gives a predicted mass multiplier of approximately 1.224 per additional millimetre of mean thickness, or about a 22.4% increase within the range represented by the data.

## Scope

This ANTH418 exercise is a deliberately simple regression used to teach fitted relationships, transformed outcomes, residuals, uncertainty, and limits of prediction.

It does not reproduce the publication's fuller multiple-regression, variable-selection, or machine-learning workflow.

The experimental design also limits automatic generalization to all archaeological lithic assemblages.

## Build script

The teaching dataset is built reproducibly in the instructor repository using:

`scripts/build_teaching_data.R`

The build script is not included in the student package and is not needed to complete the assignment.
