# Assignment 10: Predicting Flake Mass

**Week:** 14  
**Statistical focus:** Regression Analysis

## Research question

How well does mean flake thickness predict log-transformed flake mass, and what do the fitted line and residuals reveal about the model?

## Published case study

Bustos-Pérez, Guillermo, and Javier Baena. 2021. Predicting Flake Mass: A View from Machine Learning. *Lithic Technology* 46(2):130–142.

DOI: https://doi.org/10.1080/01977261.2021.1881267

## Teaching population

The student file contains **300 experimental flint flakes** from the published dataset.

The fixed teaching model is:

`log10(weight) ~ mean_thickness`

Using a fixed predictor keeps the assignment focused on regression interpretation rather than variable selection.

## Workflow

1. Read the case-study article before analysis.
2. Read `codebook.md` and `provenance.md`.
3. Open `assignment10_flake_regression.qmd`.
4. Render once before editing to confirm that R, packages, and data paths work.
5. Work through **Inspect → Visualize → Fit → Back-transform → Diagnose residuals → Interpret**.
6. Keep only output needed to support your reasoning.

## Recurring interpretation questions

1. What is the unit of analysis?
2. What are the estimated slope, its confidence interval, and R-squared?
3. What does the slope mean on the original flake-mass scale?
4. What do the residuals and the experimental data-generating process imply about limits of prediction and archaeological generalization?

## Data

The student file `data/flake_regression.csv` is a frozen teaching dataset built reproducibly from the published source data.

The original source uses semicolon-delimited fields and comma decimal marks. The teaching build preserves the published numeric values while standardizing column names and selecting variables needed for the ANTH418 exercise.

See `provenance.md`.
