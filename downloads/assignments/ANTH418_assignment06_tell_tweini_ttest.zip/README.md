# Assignment 6: Tell Tweini: Two-Group Isotope Comparison

**Week:** 9  
**Statistical focus:** Comparing Two Groups: t-tests

## Research question

Did wild ryegrass (*Lolium cf. multiflorum*) Δ13C differ between the Middle Bronze Age and Late Bronze Age at Tell Tweini, and how large and uncertain is that difference?

## Published case study

Fuller, Benjamin T., Simone Riehl, Veerle Linseele, Elena Marinova, Bea De Cupere, Joachim Bretschneider, Michael P. Richards, and Wim Van Neer. 2024. Agropastoral and Dietary Practices of the Northern Levant Facing Late Holocene Climate and Environmental Change: Isotopic Analysis of Plants, Animals and Humans from Bronze to Iron Age Tell Tweini. *PLOS ONE* 19(6): e0301775.

DOI: https://doi.org/10.1371/journal.pone.0301775

## Teaching comparison

Assignment 6 uses source-derived Δ13C values for:

- *Lolium cf. multiflorum*, Middle Bronze Age (`n = 10`);
- *Lolium cf. multiflorum*, Late Bronze Age (`n = 10`).

The effect is defined as:

**Middle Bronze Age − Late Bronze Age**

A positive value means higher mean Δ13C in the Middle Bronze Age.

## Workflow

1. Read the case-study article before analysis.
2. Read `codebook.md` and `provenance.md`.
3. Open `assignment06_tell_tweini_ttest.qmd`.
4. Render once before editing to confirm that R, packages, and data paths work.
5. Work through **Describe → Visualize → Assess assumptions → t-test → Effect size → Robustness check → Interpret**.
6. Keep only output needed to support your reasoning.

## Recurring interpretation questions

1. What is the unit of analysis?
2. What is the estimated MBA − LBA Δ13C difference and what does its sign mean?
3. What do the confidence interval, p-value, Cohen's d, and Welch robustness check tell you?
4. What climatic or agricultural claim does the comparison not establish by itself?

## Data

The student file `data/tell_tweini_ttest.csv` is a frozen teaching dataset built reproducibly from the published supporting data. See `provenance.md`.
