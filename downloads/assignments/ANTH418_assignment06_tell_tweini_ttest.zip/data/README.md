# Student teaching data

The teaching dataset `tell_tweini_ttest.csv` is created by:

```r
source("scripts/03_build_teaching_data.R")
```

Do not edit the generated CSV manually.
