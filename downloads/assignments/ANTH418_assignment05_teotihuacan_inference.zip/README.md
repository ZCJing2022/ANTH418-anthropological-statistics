# Assignment 5: Teotihuacan Leporid Management

**Week:** 8  
**Statistical focus:** Confidence Intervals and Hypothesis Testing

## Research question

How large is the δ13C difference between leporids from **Oztoyahualco** and the **Moon Pyramid**, how uncertain is it, and how unusual would that difference be under a no-difference null model?

## Published case study

Somerville, Andrew D., Nawa Sugiyama, Linda R. Manzanilla, and Margaret J. Schoeninger. 2016. Animal Management at the Ancient Metropolis of Teotihuacan, Mexico: Stable Isotope Analysis of Leporid Bone Mineral. *PLOS ONE* 11(8): e0159982.

DOI: https://doi.org/10.1371/journal.pone.0159982

## Teaching comparison

Assignment 5 uses source-valid δ13C observations from:

- Oztoyahualco: `n = 15`;
- Moon Pyramid: `n = 50`.

The effect is always defined as:

**Oztoyahualco − Moon Pyramid**

A positive value means mean δ13C is higher (less negative) at Oztoyahualco.

## Workflow

1. Read the case-study article before analysis.
2. Read `codebook.md` and `provenance.md`.
3. Open `assignment05_teotihuacan_inference.qmd`.
4. Render once before editing to confirm that R, packages, and data paths work.
5. Work through **Describe → Visualize → Estimate effect → Bootstrap uncertainty → Permutation test → Interpret**.
6. Keep only output needed to support your reasoning.

## Recurring interpretation questions

1. What is the unit of analysis?
2. What is the observed effect and what does its sign mean?
3. What do the bootstrap confidence interval and permutation p-value each tell you?
4. What archaeological claim does the analysis not establish?

## Data

The student file `data/teotihuacan_leporids.csv` is a frozen teaching dataset built reproducibly from the published supporting data. See `provenance.md`.
