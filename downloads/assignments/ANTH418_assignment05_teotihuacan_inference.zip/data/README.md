# Student teaching data

The teaching dataset `teotihuacan_leporids.csv` is created by:

```r
source("scripts/03_build_teaching_data.R")
```

Do not edit the generated CSV manually.
