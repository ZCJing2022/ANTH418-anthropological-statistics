# Assignment 9: Hawaiian Kukui Isotopes

**Week:** 13  
**Statistical focus:** Measures of Association

## Research question

Is kukui carbon-isotope composition associated with elevation, and what does rainfall add to the interpretation of that relationship?

## Published case study

Lincoln, Noa Kekuewa, Mark D. McCoy, and Thegn N. Ladefoged. 2018. Stable Carbon and Nitrogen Isotopes in Kukui (*Aleurites moluccanus*) Endocarp along Rainfall and Elevation Gradients: Archaeological Implications. *PLOS ONE* 13(10): e0204654.

DOI: https://doi.org/10.1371/journal.pone.0204654

## Teaching population

The student file contains **71 sampled kukui location/site records**.

The main teaching association is:

**elevation ↔ δ13C**

Rainfall is explored as a continuous environmental variable to help students think about covariation and potential confounding.

## Workflow

1. Read the case-study article before analysis.
2. Read `codebook.md` and `provenance.md`.
3. Open `assignment09_kukui_correlation.qmd`.
4. Render once before editing to confirm that R, packages, and data paths work.
5. Work through **Inspect → Scatterplot → Pearson correlation → Explore rainfall continuously → Interpret**.
6. Keep only output needed to support your reasoning.

## Recurring interpretation questions

1. What is the unit of analysis?
2. What are the direction, magnitude, confidence interval, and p-value for the elevation–δ13C correlation?
3. What does examining rainfall add to the interpretation?
4. What causal or archaeological inference does the correlation not establish?

## Data

The student file `data/kukui_sites.csv` is a frozen teaching dataset built reproducibly from the published supporting data. See `provenance.md`.
