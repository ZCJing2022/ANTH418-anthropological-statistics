# Data Provenance

## Publication

Lincoln, Noa Kekuewa, Mark D. McCoy, and Thegn N. Ladefoged. 2018. Stable Carbon and Nitrogen Isotopes in Kukui (*Aleurites moluccanus*) Endocarp along Rainfall and Elevation Gradients: Archaeological Implications. *PLOS ONE* 13(10): e0204654.

**DOI:** https://doi.org/10.1371/journal.pone.0204654

## Original source file

Local source file:

`source/lincoln2018_s1.xlsx`

The teaching dataset is derived from the published supporting table.

## Teaching file

`data/kukui_sites.csv`

The final teaching file contains **71 sampled kukui location/site records**.

## Unit of analysis

One sampled kukui location/site record represented in the published supporting table.

## Variables retained for teaching

The teaching file retains:

- sampling coordinates;
- elevation;
- annual rainfall;
- kukui δ13C;
- kukui δ15N.

Assignment 9 focuses on the association between elevation and δ13C.

Rainfall is retained as a continuous environmental variable so students can explore whether it covaries with elevation and/or δ13C.

## Statistical scope

The main teaching analysis is Pearson's correlation between elevation and δ13C.

Additional plots and bivariate correlations involving rainfall are exploratory.

They do **not** statistically control for rainfall, and they should not be described as estimating an adjusted effect of elevation.

A multivariable model would be required for formal adjustment.

The observed correlation does not by itself establish a causal environmental mechanism or a unique archaeological inference.

## Build script

The teaching dataset was built reproducibly in the instructor repository using:

`scripts/build_teaching_data.R`

The build script is not included in the student package and is not needed to complete this assignment.
