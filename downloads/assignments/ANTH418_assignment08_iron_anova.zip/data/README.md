# Student teaching data

The teaching dataset `iron_anova.csv` is created by:

```r
source("scripts/03_build_teaching_data.R")
```

Do not edit the generated CSV manually.
