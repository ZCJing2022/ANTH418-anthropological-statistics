# Assignment 8: Roman-Period Iron-Smelting Geochemistry

**Week:** 12  
**Statistical focus:** Analysis of Variance

## Research question

Do **CLR-transformed Si values** differ among the four iron-smelting regions HCM, MAS, SIL, and JUR, and how robust is the conclusion to imperfect ANOVA assumptions?

## Published case study

Żabiński, Grzegorz, Jarosław Gramacki, Artur Gramacki, Ivan S. Stepanov, and Marcin Woźniak. 2023. Old Wine into New Wineskins? “Legacy Data” in Research on Roman Period East Germanic Iron Smelting. *PLOS ONE* 18(10): e0289771.

DOI: https://doi.org/10.1371/journal.pone.0289771

## Teaching population

The teaching file contains **240 source-derived analytical observations**:

- HCM: 80
- MAS: 64
- SIL: 84
- JUR: 12

The fixed response variable is `Si_CLR`.

`element_value` is centered-log-ratio transformed Si, not raw Si concentration.

## Teaching workflow

1. Read the case-study article before analysis.
2. Read `codebook.md` and `provenance.md`.
3. Open `assignment08_iron_anova.qmd`.
4. Render once before editing to confirm that R, packages, and data paths work.
5. Work through **Describe → Visualize → Check assumptions → Classical ANOVA → Eta-squared → Sensitivity checks → Tukey HSD → Interpret**.
6. Keep only output needed to support your reasoning.

## Assumption caveat

Variance homogeneity is acceptable for the selected Si CLR variable, but normality is imperfect in HCM and MAS.

For that reason, the classical ANOVA is interpreted together with:

- Welch ANOVA;
- Kruskal–Wallis.

The assignment therefore treats the ANOVA as a useful but **not assumption-perfect** teaching analysis.

## Recurring interpretation questions

1. What is the unit of analysis, and what does CLR-Si represent?
2. What does the classical ANOVA indicate about regional differences?
3. What do eta-squared, Welch ANOVA, Kruskal–Wallis, and Tukey HSD add to the interpretation?
4. What metallurgical, technological, or provenance claim does the analysis not establish by itself?

## Data

The student file `data/iron_anova.csv` is a frozen teaching dataset built reproducibly from the publication's analytical materials. See `provenance.md`.
