# Codebook

Teaching file: `iron_anova.csv`

**Teaching population:** 240 source-derived analytical observations from HCM, MAS, SIL, and JUR.

**Unit of analysis:** one observation in the authors' 240-row analytical dataset.

| Variable | Type | Meaning | Units |
|---|---|---|---|
| `source_row_id` | integer | Row identifier in the authors' 240-observation ANOVA dataset | — |
| `region` | categorical | Iron-smelting region: HCM, MAS, SIL, or JUR | — |
| `element` | character | Fixed teaching variable label: `Si_CLR` | — |
| `element_value` | numeric | Centered-log-ratio transformed Si value derived from the authors' imputed Si–Ca–Al–Mn composition | CLR log-ratio units |

`element_value` is **not a raw elemental concentration**.

A higher CLR-Si value means that Si is relatively higher within the Si–Ca–Al–Mn composition, relative to the geometric mean of those components.

Regional sample sizes:

- HCM: 80
- MAS: 64
- SIL: 84
- JUR: 12
