# Data Provenance

## Publication

Żabiński, Grzegorz, Jarosław Gramacki, Artur Gramacki, Ivan S. Stepanov, and Marcin Woźniak. 2023. Old Wine into New Wineskins? “Legacy Data” in Research on Roman Period East Germanic Iron Smelting. *PLOS ONE* 18(10): e0289771.

**DOI:** https://doi.org/10.1371/journal.pone.0289771

## Original supplementary files

Local source files:

- `source/zabinski2023_s2.xls`
- `source/zabinski2023_s5.zip`

The final teaching build uses the authors' S5 reproducibility materials, especially:

- `przeworsk.csv`
- `przeworsk_NAs.csv`
- `read_data_for_ANOVA.R`

## Analytical population

The source ANOVA dataset contains **240 observations**:

- HCM: 80
- MAS: 64
- SIL: 84
- JUR: 12

## Missing-value treatment and transformation

The pre-imputation file contains 43 missing/non-positive values among Si, Ca, Al, and Mn:

- Si: 3
- Ca: 3
- Al: 26
- Mn: 11

The authors' `przeworsk.csv` is the imputed analytical dataset.

Their ANOVA workflow applies a centered-log-ratio (CLR) transformation jointly to:

- Si
- Ca
- Al
- Mn

ANTH418 reproduces that CLR transformation and retains **CLR-transformed Si** as the fixed teaching response.

## CLR interpretation

CLR-Si is relative compositional information.

A higher CLR-Si value means Si is relatively higher within the Si–Ca–Al–Mn composition relative to the geometric mean of those components.

It should not be interpreted as a raw Si concentration.

## Why Si is used

All four publication-supported CLR variables show some departure from textbook ANOVA assumptions.

Si is the least assumption-problematic for this introductory teaching case:

- Levene-style p ≈ .537
- Bartlett p ≈ .107
- normality remains imperfect in HCM and MAS

Accordingly, students compare classical ANOVA with Welch ANOVA and Kruskal–Wallis sensitivity checks.

Validated teaching results:

- classical ANOVA p ≈ .0043
- Welch ANOVA p ≈ .0158
- Kruskal–Wallis p ≈ .0031
- Tukey: 2 of 6 regional pairs significant
- eta-squared ≈ .054

## Unit of analysis

One observation in the authors' 240-row analytical dataset.

## Statistical scope

The teaching analysis is designed to show how an omnibus ANOVA, effect size, sensitivity checks, and pairwise post-hoc comparisons answer different questions.

The regional association does not by itself establish a unique metallurgical technology, ore source, or provenance mechanism.

## Build script

The teaching dataset was built reproducibly in the instructor repository using:

`scripts/build_teaching_data.R`

The build script is not included in the student package and is not needed to complete this assignment.
